import SwiftUI

struct Test2View: View {
    @State var q1AnsweredResult=""
    @State var q2AnsweredResult=""
    let close = ["容易", "不容易"]
    @State var selectclose = 0
    @State var q3AnsweredResult = 1
    let fences = ["有圍欄", "無圍欄"]
    @State var selectFence = 0
    @State var q4AnsweredResult=""
    let water = ["池塘", "河流", "湖"]
    @State var selectWater = 0
    @State var q5AnsweredResult = 1
    @State var resultText1=""
    @State var showResult = false
    func getResultString()->String{
        var resultString=""
        resultString+="1.出現在你腦海中的人，就是「你在心裡認為人生中最重要的人」，或是也可能是現在最讓你在意的人。\n\n"
        resultString+="2.你選擇的動物象徵你的「性格」，如果是難以親近的動物代表你是一個積極主動的人，反之，如果是溫和型的動物則是屬於偏被動的個性。\n\n"
        resultString+="3.房子的大小就代表「你的野心大小」，所以想像中的房子越大等於你對於未來的展望越大，而如果房子周圍沒有圍欄的話，象徵著你是一個直來直往的「直腸子派」。\n\n"
        resultString+="4.神秘的水聲象徵「情慾或性慾」，慾望越強烈就會想像更寬闊的河流～\n\n"
        resultString+="5.被浸濕的比例代表「你與戀人之間的肉體關係」，如果想像中的比例越高就代表越重視這一塊～\n\n"
        return resultString
    }
    var body: some View {
        Form {
            Group{
                Section{
                    Text("1.在風和日麗的天氣裡，你在這片森林裡走著，在旁邊陪伴你的人會是誰？")
                    TextEditor(text: $q1AnsweredResult)
                        .frame(height:100)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 2))
                }
                Section{
                    Text("2.這時這森林之中，意想不到的動物出現了！這隻動物會是什麼種類呢？")
                    TextEditor(text: $q2AnsweredResult)
                        .frame(height:100)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(lineWidth: 2))
                    Text("牠容易親近嗎？")
                    Picker(selection: $selectclose) {
                        ForEach(close.indices) {
                            i in Text(close[i])
                        }
                    } label: {
                        
                    }
                }.pickerStyle(.menu)
                
                Section{
                    Text("3.再往森林深處繼續前進之後，你們發現了一間房子，房子的規模大概多大呢？")
                    Stepper(value: $q3AnsweredResult, in: 1...10, step: 1) {
                        Text("規模大小:\(q3AnsweredResult)")
                    }
                    
                    Text("房子旁有圍欄嗎？")
                    Picker(selection: $selectFence) {
                        ForEach(fences.indices) {
                            i in Text(fences[i])
                        }
                    } label: {
                        Text("choose")
                    }
                    .pickerStyle(.segmented)
                }
                Section{
                    Text("4.附近傳來水流聲，你們決定走去一探究竟，水聲的來源是池塘、河流還是湖呢？")
                    Picker(selection: $selectWater) {
                        ForEach(water.indices) {
                            i in Text(water[i])
                        }
                    } label: {
                        Text("")
                    }
                    .pickerStyle(.wheel)
                    .frame(height:80)
                    .background(.mint)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .shadow(radius: 50)
                }
                Section{
                    Text("5.在那裡開心的玩水之後，想要回去房子那邊就必須橫越水源處，你們的身上會多濕呢？")
                    Stepper(value: $q5AnsweredResult, in: 1...10, step: 1) {
                        Text("濕的程度:\(q5AnsweredResult)")
                    }
                }
                
                Button {
                    resultText1=getResultString()
                    
                    showResult=true
                } label: {
                    Text("查看結果").font(.title2)
                }
                .sheet(isPresented: $showResult) {
                    TestResultView(showString: $resultText1,showResult: $showResult)
                }
                
                
            }
        }.navigationTitle("森林心理測驗")
    }
}
#Preview {
    Test2View()
}


