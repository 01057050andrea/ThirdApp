import SwiftUI
import MapKit
//STEP 1: You need to import the PhotosUI framework
import PhotosUI



struct InfoView: View {
    @Environment(\.calendar) var calendar
    @State var dates: Set<DateComponents> = []
    
    @FocusState private var nameIsFocused: Bool
    @State private var name = ""
    @State private var gen = ""
    @State private var gender = true
    @State private var birthday = Date()
    @State private var showAlert = false
    @State private var alertTitle = ""
    @State  var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 23.507222, longitude: 121.0), span: MKCoordinateSpan(latitudeDelta: 3, longitudeDelta: 3))
    
    /*STEP 2: You need to declare a state variable to hold the selected photo 
     from the picker */
    @State private var selectedItem: PhotosPickerItem? 
    //Put here the selected photo to manage it  
    @State private var selectedPhotoImage: Image = Image(systemName: "photo")
    
    //Just a boolean state variable which we use to show in another Screen the loaded photo
    @State private var mustShowPhoto = false
    
    var body: some View {
        Spacer()
        NavigationStack {
            Form{
                VStack{
                    /* I'm using the boolean state variable mustShowPhoto to show a 
                     gray rectangle if there is not any image to show
                     */
                    if mustShowPhoto {
                        selectedPhotoImage
                            .resizable()
                            .scaledToFill()
                            .frame(width: 150, height: 150)
                            .clipShape(Circle()) // 裁切成圓形
                            .offset(x:430)
                    }
                    else {
                        Rectangle().foregroundColor(.gray)
                            .frame(width: 150, height: 150)
                            .clipShape(Circle()) // 裁切成圓形
                            .offset(x:430)
                    }
                    
                    //STEP 3 - instantiate the picker.
                    /*
                     The 'MATCHING' parameter allows you to specify the photo filter 
                     to apply: to display both images and videos, you should change 
                     the value of the parameter to: '.any(of: [.images, .videos])'
                     Use the '.not' filter to exclude Live Photos.
                     */
                    
                    PhotosPicker(selection: $selectedItem, matching: .images) {
                        //Just beautify a bit the Text. Here you can put some nicer 
                        //view
                        Text("選擇你的大頭貼")
                            .fontWeight(.bold)
                            .offset(x:430)
                    }
                    
                    //STEP 4: monitor any change of the state variable 'selectedItem'
                    .onChange(of: selectedItem) { newItem in
                        //STEP 5: use loadTransferable method to load the asset data
                        Task {
                            if let data = try? await newItem?.loadTransferable(type: Data.self) {
                                if let uiImage = UIImage(data: data) {
                                    selectedPhotoImage =  Image(uiImage: uiImage)
                                    mustShowPhoto = true
                                }
                                else {
                                    let _ = print("***\(UIImage.description())")
                                }
                            }
                        }
                    }
                }
                Group{
                    Section{
                        TextField("姓名", text: $name, prompt: Text("姓名"))
                            //.textFieldStyle(.roundedBorder)
                            .focused($nameIsFocused)
                        Button("Submit") {
                            nameIsFocused = false
                        }
                    }
                    Section{
                        Toggle("性別：\(gender ? "男" : "女")",isOn: $gender)
                            .onChange(of: gender) {
                                newValue in 
                                if(newValue){
                                    gen = "先生"
                                }
                                else{
                                    gen = "小姐"
                                }
                            }
                    }
                    
                    DisclosureGroup("更多選項") {
                        VStack (alignment:.leading){
                            Text("出生年月日以及今天日期")
                            VStack {
                                MultiDatePicker("出生年月日以及今天日期", selection: $dates)
                                Text(summary)
                            }
                            .padding()
                            
                            var summary: String {
                                dates.compactMap { components in
                                    calendar.date(from: components)?.formatted(date: .long, time: .omitted)
                                }.formatted()
                            }
                           Text("居住地")
                            Map(coordinateRegion: $region)
                                .frame(width: 900, height: 600)
                        }
                    }
                }
                let number = Int.random(in: 0...9)
                Section{
                    Button{
                        showAlert = true
                        alertTitle = "\(number)" 
                    } label: {
                        VStack {
                            Text("你的幸運數字是")
                        }
                    }
                    .alert(alertTitle, isPresented: $showAlert) {
                        Button("OK") {
                            
                        }
                    }
                    
                }
                
                NavigationLink {
                    TestPickerView()
                } label: {
                    Text("開始測驗")
                }
            }
        }
    }
}


struct InfoView_Previews: PreviewProvider {
    static var previews: some View {
        InfoView()
    }
}
