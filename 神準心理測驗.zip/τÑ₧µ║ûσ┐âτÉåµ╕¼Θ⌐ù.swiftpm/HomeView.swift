import SwiftUI

struct HomeView: View {
    @State private var showingOptions = false
    @State private var selection = "Cat"
    @State private var scale: Double = 1
    
    var body: some View {
        NavigationStack {
            VStack{
                VStack(alignment: .center)
                {
                    Text("歡迎來到神準心理測驗！")
                        .font(.system(size:50))
                        .bold()
                        .foregroundColor(.orange)
                        .offset(y:-50)
                    Text("請點選圖片進入")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.purple)
                        .offset(y:-10)
                }
                
                NavigationLink {
                    InfoView()
                } label: {
                    Image(selection)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 200)
                        .clipShape(Circle())
                        .scaleEffect(scale)
                        .offset(y:10)
                }
                .offset(y:-15)
                Button("換圖片") {
                    showingOptions = true
                }
                .actionSheet(isPresented: $showingOptions) {
                    ActionSheet(
                        title: Text("Select an image"),
                        buttons: [
                            .default(Text("Cat")) {
                                selection = "Cat"
                            },
                            
                                .default(Text("Bear")) {
                                    selection = "Bear"
                                },
                            
                                .default(Text("Rabbit")) {
                                    selection = "Rabbit"
                                },                
                        ]
                    )
                }
                
                Slider(value: $scale, in: 0...1)
                    .tint(.orange)
                
            }
        }
    }
}


