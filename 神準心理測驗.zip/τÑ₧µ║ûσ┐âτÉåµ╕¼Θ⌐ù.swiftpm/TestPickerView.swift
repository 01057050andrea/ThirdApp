import SwiftUI

struct TestPickerView: View {
    @State var showPopup=false
    
    var body: some View {
        NavigationStack {
            ZStack{
                NavigationView {
                    List {
                        NavigationLink {
                            Test1View()
                        } label: {
                            Text("從顏色看出你的愛情")
                        }
                        
                        NavigationLink {
                            Test2View()
                        } label: {
                            Text("森林心理測驗")
                        }
                        
                        NavigationLink {
                            HomeView()
                        } label: {
                            Text("回首頁")
                        }
                        
                    }.navigationTitle("選擇測驗")
                }
            }    
            
        }
    }
}
