import SwiftUI

struct Test1View: View {
    @State var SelectedColor=Color.black
    @State var showAlert=false
    @State var resultText=""
    @State private var drawHexNumber: String = "#000000"
    @State var selectedIndex=1.0
    @State var resultText2=""
    @State var selectedIndex2=1.0
    @State private var showingAnswer = false
    
    func getColorsFromPicker(pickerColor: Color) {
        let colorString = "\(pickerColor)"
        let colorArray: [String] = colorString.components(separatedBy: " ")
        
        if colorArray.count > 1 {
            var r: CGFloat = CGFloat((Float(colorArray[1]) ?? 1))
            var g: CGFloat = CGFloat((Float(colorArray[2]) ?? 1))
            var b: CGFloat = CGFloat((Float(colorArray[3]) ?? 1))
            
            if (r < 0.0) {r = 0.0}
            if (g < 0.0) {g = 0.0}
            if (b < 0.0) {b = 0.0}
            
            if (r > 1.0) {r = 1.0}
            if (g > 1.0) {g = 1.0}
            if (b > 1.0) {b = 1.0}
            
            if(r < 20.0/255 && g < 20.0/255 && b < 20.0/255){ //black
                selectedIndex = 1
            }else if(r > 200.0/255 && g < 150.0/255 && b <= 70.0/255){
                //red
                selectedIndex = 2
            }else if(r > 200.0/255 && g >= 150.0/255 && b <= 70.0/255){
                //yellow
                selectedIndex = 3
            }else if(r < 100.0/255 && g >= 150.0/255 && b <= 100.0/255){
                //green
                selectedIndex = 4
            }else if(r < 180.0/255 && g < 140.0/255 && b <= 180.0/255){
                //blue
                selectedIndex = 5
            }else if(r > 235.0/255 && g > 235.0/255 && b > 235.0/255){
                //white
                selectedIndex = 6
            }
            
            
            
            // Update hex
            let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
            drawHexNumber = String(format: "#%06X", rgb)
        }
    }
    func getResultString()->String{
        if(Int(selectedIndex)==1){
            return "你選擇的顏色象徵主觀，因此選擇此顏色的人通常很自我中心，無法與他人相處。喜歡對方配合自己、個性固執，最好不要讓對方改變自己。"
        }
        if(Int(selectedIndex)==2){
            return
            "你選擇的顏色象徵著肯定與信念，生活中大多時候非常有自信，你對於自己的抉擇堅信不移，想要在愛情中握有領導權，因此容易被冷靜沉穩、直言不諱坦率的對象所吸引。"
        }
        if(Int(selectedIndex)==3){
            return
            "你選擇的顏色象徵好奇心與自由，你是一個自由放在第一順位的人，比起規則與框架，你更喜歡自由與創造性。因此你總是充滿好奇心，喜歡挑戰越困難越好！因此你特別會被那些同樣愛冒險的夥伴吸引。"
        }
        if(Int(selectedIndex)==4){
            return
            "你選擇的顏色象徵和平與和諧，比起自己你更優先考量到他人的感受，往往會在感情中受傷吃虧。容易成為理想愛情中的犧牲者，因此你也容易被富有同理心、個性溫和的人吸引。"
        }
        if(Int(selectedIndex)==5){
            return
            "你選擇的顏色象徵靈感與寬容，你強烈的希望被身邊的人認可，因此不論是工作還是私底下，你都會毫不懶惰的表現自己。有很多興趣同時對工作也很有熱忱，通常會被看得見你的好、常稱讚自己的人吸引。"
        }
        if(Int(selectedIndex)==6){
            return "你選擇的顏色象徵著完美和正義，大部分的生活中都很有正義感，對於自我評價基於道德觀與價值觀來說，可謂一個「正直的人」在愛情中挑選理想型時，容易被有正義感、形象完美的對象所吸引。"
        }
        else{
            return " "
        }
        
    }
    func choose()->String{
        if(selectedIndex2==1.0){
            return "A"
        }
        if(selectedIndex2==2.0){
            return "B"
        }
        if(selectedIndex2==3.0){
            return "C"
        }
        if(selectedIndex2==4.0){
            return "D"
        }
        return "E"
    }
    func getResultString2()->String{
        if(Int(selectedIndex2)==1){
            return "你是人前面面俱到的圓滑外交官，內心渴望鍾情你一人的浪漫戀愛\n\n你擅於體察他人的情緒需求，並有能力用合適的方式滿足對方，交友廣泛的你能敏銳的捕捉到，誰跟誰之間也許擁有彼此需要的資源、技能，常常不小心就促成合作、幫忙牽線。而且手腕輕巧俐落，不經意間就讓彼此搭上線，一點也不刻意。因此你可能就是朋友圈當中的媒人，眼光精準可靠、作風又自然不尷尬，牽來牽去就剩自己沒著落。\n\n你對於自己的要求很高，尤其在待人處事方面，總能保持優雅圓滑，這樣能力優秀的你自然眼光也不差。在你內心深處其實渴望著浪漫的戀情，你其實很容易被懂得滿足對方情感需求、洋溢藝術浪慢氣質的人吸引。對方可能情感豐富（情史也豐富）善於運用說話、肢體語言、臉部表情來表達情感，輕鬆散發魅力。面面俱到的你，內心渴望的是被鍾情對待。"
        }
        if(Int(selectedIndex2)==2){
            return "你是喜歡躲在自己天地的怪怪隱士，尋找能陪伴自己相守山洞的知心人\n\n平時你有自己喜愛研究和感興趣的事物，可能有不為人知、低調或與眾不同的愛好，可以花很多時間在自己有興趣喜歡的事物上，相反可能就一點都提不起勁。很需要自己的空間，沈浸在自己的世界時不想被打擾。\n\n這樣的你容易被簡單敏感、善於表達的心靈觸動。不需要多轟轟烈烈、戲劇化的事件。這樣的他們可能擅於發現生活中平凡的美好，並能透過語言、文字去表達出來，因為表達是你的罩門，所以特別欣賞能直接說出內心想法感受的人。這樣的你內心其實很單純透明，適合一樣擁有單純美好心靈的對象，一起相伴每個看似平凡卻又溫暖的日常。"
        }
        
        if(Int(selectedIndex2)==3){
            return 
            "你是富有同情心易受傷的敏感彼得潘，需要有一雙翅膀的遠見家一起飛翔\n\n你也許在創傷中長大，擁有一顆比一般人更加纖細、易感也易碎的心。這也讓你很有同理心、同情心，願意去幫助他人，在你的愛裡更有一份大愛的品質，希望大家能夠一起共好，有時容易吸引非正常的戀愛關係和情境。正走在療癒自己的路上。\n\n適合一樣心繫社會，同時包容大氣，擁有寬廣的心胸與眼界的另一半。這樣的他既有跟你一樣的價值觀，又能包容你纖細的心，你們都有一點理想主義的夢幻特質，但當你們找到志同道合的人，就能支持彼此、集結力量改變世界！"
        }
        
        if(Int(selectedIndex2)==4){
            return
            "你是善於權衡想法堅定的法官，忠於慾望等待一拍即合的魅力尤物\n\n你對於自己想要的是什麼，總是很明確，也很明白可以用什麼東西來換取什麼等價的事物。很實際、善於分配盤算，讓誰都不會吃虧。（至少你不會吃虧，同時也欣賞跟你一樣堅定自己想法的人）不管外表看起來如何，你內心深處是理智的在面對生活與工作的。\n\n這樣的你容易被熱情大膽、充滿魅力的人吸引，最讓你熱血沸騰的是大人式的戀愛，勇於展現自己的慾望，說出自己想要的，有點高手過招的刺激。但當確定彼此都是對方理想合適的對象時，你會為對方與這段關係許下深情的承諾，你是個專一也願意並有能力好好經營感情的對象。"
        }
        
        return
        "你是信念純粹的聖潔處女，就愛心目中的夢幻公主/夢幻王子\n\n你對於這個世界和愛情有自己的看法和信仰，有你的世界觀、價值觀，是個理想主義者，你很難妥協於你沒有感覺、不認同的事物。對自己相信的事堅定不移、信念純粹，同時心中懷有柔軟的愛、夢和理想。\n\n你容易被和與你有類似特質的人吸引，對方擁有美麗夢幻、大家閨秀的特質最是你的菜，你是所有角色類型中最博愛也最有自己理想型的人。喜歡夢中情人的類型，你很浪漫，當你遇到心目中的男神/女神，你願意帶著崇高的意志服侍對方，容易被外表和氛圍吸引，確確實實是個外貌協會者。"
    }
    var body: some View {
        Form{ 
            Section {
                Text("1.你最喜歡的顏色是？")
                ColorPicker("選擇顏色", selection: $SelectedColor,supportsOpacity: false).onChange(of: SelectedColor) { newValue in
                    getColorsFromPicker(pickerColor: newValue)
                }
                
            }
            Button {
                resultText = getResultString()
                showAlert=true
            } label: {
                Text("查看結果").font(.title2)
            }.alert(getResultString(),isPresented: $showAlert) {
                Button("OK"){}
            }
            
            Section {
                Text("2.選擇你最有感覺的圖案！")
                Image("Light").resizable().scaledToFill()
                Text("我的選擇: \(choose())")
                Slider(value: $selectedIndex2, in: 1.0...5.0, step: 1.0) {
                    Text("choose")
                }
            }
            
            Button("查看結果") {
                showingAnswer.toggle()
            }
            .sheet(isPresented: $showingAnswer) {
                Text("\(getResultString2())")
                    .presentationDetents([.medium, .medium])
            }
        }
        .navigationTitle("從顏色看出你的愛情")
    }
}


#Preview {
    Test1View()
}
