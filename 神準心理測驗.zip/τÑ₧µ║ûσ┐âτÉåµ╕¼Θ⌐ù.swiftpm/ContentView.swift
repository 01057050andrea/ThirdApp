import SwiftUI

struct ContentView: View {
    @State private var showingInfo = false
    
    var body: some View {
        if(showingInfo){
            InfoView()
        }else{
            HomeView()
        }
        
    }
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewInterfaceOrientation(.portrait)
    }
}
